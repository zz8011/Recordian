Recordian - Linux 语音输入助手
================================

快速开始：
1. 运行 ./install.sh 安装
2. 从应用菜单启动 Recordian
3. 使用右 Ctrl 键触发语音输入

详细说明请查看 INSTALL.md

